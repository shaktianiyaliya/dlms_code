// 5. read integer without using scanf


#include<stdio.h>
#include<stdlib.h>


int main( int argc,char *argv[] )

{
	unsigned int lNum ;

	if( argc != 2 )
	{
		printf( " ** please enter ./a.out and any number\n **" );
		return;
	}

	lNum = atoi( argv[1] ) ;
	printf( "%d",lNum ) ;

return 0;

}
