// 1b . program to set n bits of given with given value


#include<stdio.h>

int Bit_count(int x);
void print_bit ( int Number , int bit ) ;

int main()
{
	unsigned int lNumber1, lNumber2, bit, cCountbit, result;
	int i ;
	unsigned int lTemp1, lTemp2;

	printf ( " enter the first number\n" );
	scanf ( "%d", &lNumber1 );

	printf ( " enter the second number\n" );
	scanf ( "%d", &lNumber2 );

	printf ( "enter the number of bits to be set\n" );
	scanf ( "%d", &bit );

	printf ( " n1 and n2 are\n" );

	cCountbit = Bit_count ( lNumber1 );

	//convert ( lNumber1 , cCountbit );
	print_bit (  lNumber1 ,  cCountbit ) ;
	printf ("\n \n");

	cCountbit = Bit_count ( lNumber2 );
	//convert ( lNumber2 , cCountbit );
	print_bit ( lNumber2 , cCountbit ) ;
	

	for ( i = 0; i<bit; i++)
	{
		lTemp1 |= ( lNumber2 & ( 1 << i ) ) ;
	}

	lTemp2 = ( lNumber1 >> bit ) << bit ;
	lTemp1 |= lTemp2 ;

	printf ("\nNumber after setting is %d\n", lTemp1 );
	printf (" set Number is:  \n ");

	cCountbit = Bit_count ( lTemp1 );
	//convert ( lTemp1 , cCountbit );

	print_bit ( lTemp1 , cCountbit ) ; 
	return 0;
}


void print_bit ( int Number , int bit ) 
{
	int iter ;
	for ( iter = 0; iter <bit ; iter ++)
	{
		printf ( "%d" , !! ( Number & ( 1 << iter ) ) ) ;
		
	}
}








int Bit_count ( int x )
{
	int cCountbit = 0 ;

	while ( x )
	{
		cCountbit++ ;
		x = x >> 1 ;
	}
	return cCountbit ;
}






/*

void convert ( int n, int bits )
{
	int i;

	for( i = 1 << bits - 1 ; i > 0 ; i/= 2 )
	{
		( n&i ) ? printf ( "1" ) : printf ( "0" );
	}
*/
