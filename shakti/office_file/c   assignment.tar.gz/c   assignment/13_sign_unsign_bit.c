
// 13. read the number from user and to print the value of signed and unsigned types of that number in bits.

#include<stdio.h>
#include<string.h>

void print_bit ( int value ) ; 

int main()
{

	int lNum1;

	unsigned int lNum2  ;

	printf ( "Enter sign integer and unsigned integer number:\n" ) ;
	scanf ( "%d%d", &lNum1 , &lNum2 );

	printf ( "sign bit is \n") ;

	print_bit ( lNum1 );
	
	printf ("\n");
	
	printf ( "unsigned bit is \n") ;

	print_bit ( lNum2 );

	return 0;

}

void print_bit ( int Number ) 
{
	int iter ;
	for ( iter =31 ; iter >= 0 ; iter --)
	{
		printf ( "%d" , !! ( Number & ( 1 << iter ) ) ) ;
		if ( iter % 8 == 0 )
			printf ( " " ) ;
	}
}














/*void convert(int n)

{
	int i,mask;

	for ( i = 31; i>=0; i--)
	{
		mask = 1 << i;
		( n & mask ) ? printf ("1") : printf ( "0" );

		if ( i%8 == 0)

		printf (" ");
	}

*/

