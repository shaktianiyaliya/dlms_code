// 8. program to implement a function that deletes each character in string1 that matches any character in the string2.


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
 
int main ()
{
	char str1[100], str2[100], str_rem[100];
	int i = 0, j = 0, k = 0;
 
	printf ("Enter the First string:\n");
    
	gets (str1);
 
	printf ("Enter the Second string:\n");
	gets (str2);
 
	for (i = 0; str2[i]!= '\0'; i++)
	{
		for (j = 0; str1[j] != '\0'; j++)
		{
			if (str2[i] == str1[j])
			{
				continue;
			}

			else
			{
				str_rem[k] = str1[j];
				k ++;
			}
		}

	str_rem[k] = '\0';
	strcpy (str1, str_rem);
	k = 0;

	}
 
	printf ("after removing characters from second string we get first string is: %s\n", str_rem);
 
	return 0;

}
