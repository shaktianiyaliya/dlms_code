 //  1c. Get n bits from specified position


#include<stdio.h>

void get_bit ( int value , int bits );

int main()
{
	unsigned int Number, Bits, Mask, pos;
	int iter ;
	
	printf ("enter a number : \n" ) ;
	scanf ("%d", &Number );
	
	printf ("enter number of  position\n");
	scanf ( "%d", &pos ) ;

	printf ( " Position is :\n " ) ;
	get_bit ( Number , pos ) ;
}


void get_bit ( int Number , int bit ) 
{
	int iter ;
	for ( iter = 0; iter <bit ; iter ++)
	{
		printf ( "%d" , !! ( Number & ( 1 << iter ) ) ) ;
		
	}
}

