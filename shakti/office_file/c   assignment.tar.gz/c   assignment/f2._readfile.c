// f2. read an existing file.Take file name from user 

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;
	char str[100], filename[20];
	char ch;

	printf ( "enter file name:\n" );
	scanf ( "%s",filename );

	fptr = fopen ( filename,"r" );
	if ( fptr == NULL )
	{
		printf ( "Error in file open" );
		exit (1);
	}


	while ( ( ch = fgetc ( fptr ) ) != EOF )
	{
		printf ( "%c", ch);
	}

	fclose (fptr);

	return 0;
}







