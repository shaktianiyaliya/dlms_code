// 12. copy one file contents to in another file

#include<stdio.h>
#include<stdlib.h>

int main()
{
	FILE *f1, *f2;
	char file1[20], file2[20];
	char ch;

	printf ( "enter file1 name: \n" );
	scanf ( " %s", file1 );

	printf ( "enter file2 for copy data from file1: \n" );
	scanf ( "%s", file2 );

	f1 = fopen ( file1,"r" );
	if( f1 == NULL )
	{
		printf ( "Error in file open" );
		exit(1);
	}

	f2 = fopen ( file2,"w" );
	if( f2 == NULL )
	{
		printf ( "Error in file open" );
		exit(1);
	}
	while (( ch = fgetc (f1)) !=EOF )
	{
		fputc ( ch,f2 );

		printf ( "%c", ch );

	}

	fclose (f1);
	fclose (f2);

	return 0;
}
