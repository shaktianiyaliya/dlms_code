//  f5. replace a specific line with another text in a file


#include <stdio.h>
#include <stdlib.h>

#define SIZE 1000


int main()
{
    
    FILE * fPtr;
    FILE * fTemp;
    char filename[100];
    
    char buffer[SIZE];
    char newline[SIZE];
    int line, count=0;


    printf("Enter file name: \n " );
    scanf("%s", filename);

    printf("Enter line number to replace: ");
    scanf("%d", &line);

   
   
    printf("Replace '%d' line with: ", line);
    fgets(newline, SIZE, stdin);


    
    fPtr  = fopen(filename, "r");
    fTemp = fopen("test.txt", "w"); 

    
    if (fPtr == NULL || fTemp == NULL)
    {
       
        printf("Error in file open\n");
        printf("Error in file open\n");
        exit(1);
    }
    
    while ((fgets(buffer, SIZE, fPtr)) != NULL)
    {
        count++;

      
        if (count == line)
            fputs(newline, fTemp);
        else
            fputs(buffer, fTemp);
    }


    
    fclose(fPtr);
    fclose(fTemp);


    

    printf("\nSuccessfully replaced '%d' line with '%s'", line, newline);

    return 0;
}
