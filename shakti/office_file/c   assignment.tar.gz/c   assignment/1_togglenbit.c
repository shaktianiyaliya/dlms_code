//1_e.  Toggle n bits from specified position

#include<stdio.h>

void print_bit ( int value ) ;

int main()
{
	unsigned int lNumber , lPosition ;

	printf( "enter number :\n");
	scanf("%d", &lNumber );

	printf ( " \n ");

	print_bit (  lNumber ) ;

	printf (" \n ");

	printf("enter which postion to be toggle :\n");
	scanf("%d", &lPosition );

	printf ( "\n ");


	lNumber = lNumber ^ ( 1 << lPosition ) ;

	 print_bit ( lNumber ) ;

	printf ( " \n \n " );

	printf ("after toggle number is = %d ", lNumber );


}

void print_bit ( int Number ) 
{
	int iter ;
	for ( iter =31 ; iter >= 0 ; iter --)
	{
		printf ( "%d" , !! ( Number & ( 1 << iter ) ) ) ;
		if ( iter % 8 == 0 )
			printf ( " " ) ;
	}
}













/*

void convert( int n )
{
	int iteration ;
	unsigned int lmask ;
	for( iteration = 15 ; iteration >= 0 ; iteration --)
	{
		lmask = 1 << iteration ;
		( lmask & n ) ? printf ( "1" ) : printf ( "0" ) ;
		if( iteration % 4 == 0 )
		{
		     printf (" ");
		}
	}
}

*/
