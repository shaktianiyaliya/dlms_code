
#include <stdio.h>

int get_bit ( int value , int bit ) ;

void print_bits(int value1);

int main ()

{
	unsigned int Number ,bit ;
	
	printf ( " Enter any HexaDecinal value : \n " ) ;
	scanf ( "%x" , &Number ) ;

	printf ( " Enter  how many bit you want ??  : \n " ) ;
	scanf ( "%d" , &bit ) ;

	printf ( " At give bit %d and  number is  = %d ",bit, get_bit ( Number , bit ) ) ;

	//print_bits(get_bit ( Number , bit ));

	return 0 ;
}


void print_bits(int x)
{
	int iter = 0, size = sizeof( x ) * 8;
	
	printf("Binary representation of number %d is as below\n", x); 
	for(iter = 0; iter < size; iter++)
	{
		printf("%d", !! ( x  & (1 << iter)));
	}
	printf("\n");
}

int get_bit ( int Number , int bit ) 
{
 	int mask = 0 , i , x ;
 
	for ( i = 0 ; i < bit  ; i ++  )
	
	{
		mask = mask | ( 1 << i ) ;
	}

	x = Number & mask ;
	
	return x ;


}
 
  
