//  9. print bits of float and double in IEEE format


#include<stdio.h>

void print_int_bit ( int value ) ;

int main()
{
	double lNum1;
	unsigned int lNum2, m[30] ;
	int i=0 , j=0 , k=0 ;
	float lNum3;
	
	printf ( " enter any float number  :\n ");
	scanf (" %lf", &lNum1);
	
	lNum2 = lNum1 ;
	lNum3 = lNum1 - lNum2 ;
	
	printf ( " num2= %d and num3= %f", lNum2 ,lNum3);
	printf ( "\n");

	
	print_int_bit ( lNum2 ) ;

	printf ( "." );


	for ( j=0; j<8; j++ )
	{
		lNum3 = lNum3 * 2 ;
		k = lNum3;
		printf ( "%d", k );

		if ( k == 1 )
		{	
			lNum3 = lNum3 - k ;
		}
		
	}

	return 0;

}


void print_int_bit ( int lNum ) 
 {
	int iter ;
	for ( iter =15 ; iter >= 0 ; iter --)
	{
		printf ( "%d" , !! ( lNum & ( 1 << iter ) ) ) ;
		if ( iter % 4 == 0 )
			printf ( " " ) ;
	}
 }










 /*
	while ( lNum2 !=0 )
	{
		m[i] = lNum2 % 2;
		lNum2 = lNum2 / 2;
		i++;
	}
	
	for ( i = i-1; i>=0; i-- )
	{
		printf ( "%d", m[i] );
	}*/
