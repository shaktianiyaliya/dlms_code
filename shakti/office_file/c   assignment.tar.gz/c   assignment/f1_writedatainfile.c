// f1. create and store information in a text file

#include<stdio.h>
#include<stdlib.h>

int main()

{

	FILE *fptr;
	char str[100] ;
	char ch;
	unsigned int line ; 
	int i ;

	
	printf ( " Please Enter How many line data you write : \n" );
	scanf ( "%d", &line);

	printf ( "Enter data :\n" );
	gets (str);


	
	fptr = fopen ("test.txt","w");
	if ( fptr == NULL )
	{
		printf ( "Error in file open \n" );
		exit (1);
	}
	
	for ( i=0; i < line;i++ )
	{
		fgets ( str, sizeof(str),stdin);
		fputs ( str,fptr );
	}

	printf ( " check this data in ' test.txt ' file \n");
	
	fclose (fptr);

	return 0;
}

