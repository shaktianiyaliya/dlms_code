//1f.  Print the bits of the given number

#include<stdio.h>

void print_bit ( int value ) ; 

int main()
{
	unsigned int Number, mask ;
	int iter ;
	printf( "enter number :\n ");
	scanf( "%d", &Number );

	print_bit ( Number )   ;

	return 0 ;

}

void print_bit ( int Number ) 
{
	int iter ;
	for ( iter =31 ; iter >= 0 ; iter --)
	{
		printf ( "%d" , !! ( Number & ( 1 << iter ) ) ) ;
		if ( iter % 8 == 0 )
			printf ( " " ) ;
	}
}

