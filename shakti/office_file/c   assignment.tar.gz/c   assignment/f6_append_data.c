// f6.  append multiple line data in file pgm

#include<stdio.h>
#include<stdlib.h>

int main()

{

	FILE *fptr;
	unsigned int line ;
	int i;
	char str[500];

	printf ( "enter nunber of line for append multiple line data :\n" );
	scanf ( "%d",&line );

	printf ( "enter multiple line data: \n" );
	scanf("%[^\n]", str );
	
	fptr = fopen ( "test2.txt","a" );
	if ( fptr == NULL )
	{
		printf ( "Error in file open" );
		exit ( 1 );
	}

	for ( i = 1; i<=line; i++)
	{
		fgets ( str, sizeof ( str ), stdin );
		fputs ( str, fptr );
	}
		
	fclose ( fptr );

	printf ( "\n  This Append Data in  ** test2.txt ** file \n ");
	
	return 0;
}

