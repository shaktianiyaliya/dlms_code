// 14. Segregate 0s on left side and 1s on right side of the array. 


#include <stdio.h>
#define SIZE 64

int main ()

{

	int arr[SIZE] ,n ;
	int i, cCount=0;

	printf ( "Enter How many 0's and 1's You want : \n " ) ;
	scanf ( "%d" , &n ) ;
	printf ( "Enter only 0's and 1's : \n " ) ;

	for ( i = 0 ; i < n ; i++ )
	scanf ( "%d" , &arr[i] ) ;
  
	for ( i = 0 ; i < n ; i++ )
	{
		if ( arr[i] == 0 )
		{
			cCount++;
		}
	}


	for ( i = 0 ; i < cCount ; i++ )
	{
		arr[i]=0;
	}

	for ( i = cCount; i<n; i++)
	{
		arr[i]=1;
	}


	for ( i = 0; i<n; i++)
	{
		printf("%d ",arr[i]);
	}
	
	return 0;
}
