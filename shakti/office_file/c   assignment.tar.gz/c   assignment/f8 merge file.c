//  f8. merge two files and write it in a new file


#include<stdio.h>
#include<stdlib.h>

int main()

{

	FILE *f1, *f2, *f3;
	char file1[20],file2[20],file3[20];
	char c;

	printf ( "enter file1 name: \n" );
	scanf ( "%s", file1 );

	printf ( "enter file2 name t: \n" );
	scanf ( "%s", file2 );

	printf ( "enter file3 name :\n" );
	scanf ( "%s", file3 );

	f1 = fopen ( file1, "r" );
	if ( f1 == NULL )
	{
		printf ( "Error in file open" );
		exit ( 1 );
	}


	f2 = fopen ( file2, "r" );
	if ( f2 == NULL )
	{
		printf ( "Error in file open" );
		exit ( 1 );
	}


	f3=fopen(file3,"a");
	if(f3==NULL)
	{
		printf("Error in file open");
		exit(1);
	}


	while ( ( c = fgetc ( f1 ) ) !=EOF )
	{
		fputc ( c, f3 );

	}
	while ( ( c = fgetc ( f2 ) ) !=EOF )
	{

		fputc ( c, f3 );

	}
	fclose ( f1 );

	fclose ( f2 );

	fclose ( f3 );

	printf ( " \n Data stored in ** file3 ** \n" );
	printf ( " \n ** Please Open File3 ** \n" );

	return 0;

}

