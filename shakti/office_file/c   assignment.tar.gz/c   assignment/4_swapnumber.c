// 4. swap numbers using bitwise operator.


#include<stdio.h>

int swap ( int *x ,int *y ) ;

int main()
{
	int lNum1, lNum2 ; 

	printf( "enter two number: \n" ) ;
	scanf( "%d%d",&lNum1, &lNum2 ) ;


	swap ( &lNum1, &lNum2 ) ;

	printf( "after swaping  num1=%d  and num2=%d\n", lNum1, lNum2 ) ;

	return 0 ;
}


int swap ( int *num1, int *num2 )
{ 

	*num1 = *num1 ^ *num2 ;
	*num2 = *num1 ^ *num2 ;
	*num1 = *num1 ^ *num2 ;

}
