//  2.  copy bits from start position to end position from a number


#include <stdio.h>

void print_bit ( int n , int bit );


int main()

{

	unsigned int Number, Pos;

	
	printf ( "enter any number :\n " );
	scanf ( "%d", &Number );

	

	printf ( "Enter staring bit position :\n" );
	scanf ( "%d", &Pos );

	print_bit ( Number , Pos ) ;
	
	return 0;

}

	

void print_bit ( int Number , int Pos) 
{
	int iter ;
	for ( iter =15 ; iter >=Pos ; iter -- )
	{
		printf ( "%d" , !! ( Number & ( 1 << iter ) ) ) ;
		if ( iter % 4 == 0 )
			printf ( " " ) ;
	}

}



// another way to print bits
/*void convert ( int lNumber , int lPos )
	{
		int iter, size , j , k, arr[20] ;

		while ( lNumber !=0 )
		{
			arr [iter] = lNumber % 2;
			lNumber = lNumber / 2;
			iter ++ ;
		}

		size = iter;

		printf ( " binary of Enter number is \n" );

		for ( j = iter - 1 ; j >= 0 ; j -- )
		{
			printf ( "%d" , arr[j] );
		}
	
		printf ( "\n \n" );

		printf ( " final Results is  \n" );


		for ( k = size-1; k >= lPos ; k-- )
		{
			printf ( "%d" , arr[k] );
		}

	
	/*printf ( " final Results is  \n" );


		for ( k = size-1; k >= lPos ; k-- )
		{
			printf ( "%d" , arr[k] );
		}*/
	
	}*/



