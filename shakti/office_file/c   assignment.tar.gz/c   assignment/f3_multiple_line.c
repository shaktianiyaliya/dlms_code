// f3.  write multiple line data in file program



#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;
	unsigned int line ; 
	int i ;
	char str[500];

	printf ( "enter number of line : \n" );
	scanf ( "%d", &line );

	printf ( "enter multiple line data: \n" );
	gets ( str );


	fptr = fopen ( "test2.txt", "w" );
	if ( fptr == NULL )
	{
		printf ( "Error in file open" );
		exit (1);
	}


	for ( i = 1; i<=line; i++)
	{

		fgets ( str, sizeof(str), stdin);
		fputs ( str,fptr );
	}
	fclose ( fptr );

	printf ( "\n this data is stored in ' test2.txt ' file \n");

	return 0;
}

