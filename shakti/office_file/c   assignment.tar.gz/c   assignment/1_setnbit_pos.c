//1_d. Set n bits of a number with the n bits of given value from specified position

#include<stdio.h>

void convert(int n);

int main()

{	unsigned int lNumber, lPosition;

	printf ( "enter number : \n" ) ;
	scanf ( "%d", &lNumber ) ;	

	convert ( lNumber );

	printf (" \n \n");

	printf ( "enter which bit to be set :\n");
	scanf ("%d", &lPosition ) ;

	lNumber = lNumber | ( 2 * lPosition );

	convert ( lNumber );
	
	printf ( "\n \n ");

	
	printf ("after setting bit number is  = %d ", lNumber ) ;


}

void convert( int lNumber )
{
	int iter ;
	for ( iter =31 ; iter >= 0 ; iter --)
	{
		printf ( "%d" , !! ( lNumber & ( 1 << iter ) ) ) ;
		if ( iter % 8 == 0 )
			printf ( " " ) ;
	}
}
