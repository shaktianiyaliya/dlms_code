// 11. read n x n person names, sort and print the names    


#include <stdio.h>
#include <string.h>

int main()
{

	char name[10][10] , temp[10];
	int i, j ;
	unsigned int n;

	printf("Enter  value of n for how many name you want ??  \n");
	scanf("%d", &n);
	
	printf("Enter %d names n \n", n);

	for (i = 0; i < n; i++) 
	{
		
		scanf("%s", name[i]);

		
	}

	for (i = 0; i <= n ; i++)
	{
		for (j = i + 1; j < n; j++)
		{
			if (strcmp(name[i], name[j]) > 0) 

			{
				strcpy(temp, name[i]);
				strcpy(name[i], name[j]);
				strcpy(name[j], temp);
			}
		}
	}

	printf ( "Sorted names\n" );

	for (i = 0; i < n; i++) 
	{
		printf ( "%s\n",  name[i] );
	}
	return 0;

}
