// 10.  check the endianess of the processor.

#include<stdio.h>

int main()

{

	unsigned int num=0x985410;


	char *c=(char*)&num;

	if(*c == 0x10)
	{
		printf("little endian");
	}
	else
	{
		printf("big endian");
	}
	return 0;
}
