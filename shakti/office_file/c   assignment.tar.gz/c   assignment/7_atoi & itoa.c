// 7.  implement atoi and itoa functions

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

int main() 

{
 
	unsigned int lVal; 
	unsigned int a=54325;
	char str[20] = "12546"; 
	char buffer[20];

	val = atoi ( str ); 
	printf("String value = %s\n", str); 
	printf("Integer value = %d\n", val); 

	itoa( a, buffer, 10 ); 
  
	printf("Decimal value = %s\n", buffer);
	
 	return 0;


} 

