// 6.  Find the Number of Lines, words and character in a Text File

#include<stdio.h>
#include<stdlib.h>

void read_file_data(FILE *file) ;

int main()
{
	FILE *file;
	char ch , filename[30];

	//int character=0, word=0, line=0 ;
	//char ch;

	printf(" enter file name :\n") ;
	gets(filename);

	file = fopen ( filename , "r" ) ;
	if ( file == NULL )
	{
		printf("Error in file open") ;
		exit(1) ;
	}



	read_file_data(file) ;
	
	
}


void read_file_data( FILE  *file )
{
	int character=0, word=0, line=0 ;
	char ch;
	ch = fgetc(file);

	while ( ch != EOF )
	{
		printf("%c",ch);

		character++;

		if ( ch == ' ' || ch == '\n' || ch == '\0' || ch == '\t' )
		{
			word++;

			if ( ch == '\n' || '\0' )
			{
				line++;
			}
		}

		

		ch=fgetc(file);

	}
	printf( " number of character in file=%d \n", character-word-1 );
        printf( " number of word in file =%d \n", word-1 );
	printf( " number of line in file =%d \n", line-1 );



	

	





}

