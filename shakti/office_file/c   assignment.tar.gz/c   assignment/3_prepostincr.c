//3. implement pre and post increment using bitwise operators 

#include<stdio.h>

int pre_increment ( int  *n1 )  ;
int post_increment ( int  *n2 ) ;

int main( )
{
	unsigned int lNum ;
	unsigned int *p ;
	p = &lNum ;

	printf( "enter number:\n" ) ;
	scanf( "%d",&lNum ) ;

	lNum=pre_increment(p) ;

	printf( "pre increment number is =%d\n", lNum ) ;
	
	post_increment(p) ;	
	lNum=post_increment(p) ;
	

	printf("post increment number is =%d\n", lNum ) ;
}

int pre_increment(int *n1)
{

	unsigned int lMask=1;
	while( *n1 & lMask )
	{
		*n1 = *n1 ^ lMask ;
		lMask = lMask << 1 ;
	}

	*n1 = *n1 ^ lMask;
	
return *n1 ;

}


int post_increment( int *n2 )

{

	unsigned int lMask=1;
	while( *n2 & lMask )
	{
		*n2 = *n2 ^ lMask;
		lMask <<= 1;
	}
	*n2 = *n2 ^ lMask;
	
return *n2-1;

}
 

